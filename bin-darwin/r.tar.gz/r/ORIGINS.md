# ORIGINS

Each file in the bin directory is simply a fork of
`realpath.sh` has been gotten from:
[sh-realpath](https://github.com/mkropat/sh-realpath/blob/master/realpath.sh)
project
