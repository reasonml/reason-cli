1.3 (05/02/2018)
----------------

- Switch to jbuilder
