let warn_latin1 lexbuf =
  Location.prerr_warning (Location.curr lexbuf)
  (Warnings.Deprecated "ISO-Latin1 characters in identifiers")
;;
