let datadir    = Filename.concat InstallConfig.share_dir "database"
let localedir  = Filename.concat InstallConfig.share_dir "locales"
let charmapdir = Filename.concat InstallConfig.share_dir "charmaps"
let unimapdir  = Filename.concat InstallConfig.share_dir "mappings"
